package com.example.macbookpro.capamedina.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.macbookpro.capamedina.MainActivity;
import com.example.macbookpro.capamedina.R;
import com.example.macbookpro.capamedina.modelo.Producto;

import java.util.ArrayList;

public class ProductoAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Producto> listaProducto;

    public ProductoAdapter(Context context, ArrayList<Producto> listaProducto) {
        this.context = context;
        this.listaProducto = listaProducto;
    }

    @Override
    public int getCount() {
        return listaProducto.size();
    }

    @Override
    public Object getItem(int position) {
        return listaProducto.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
            convertView = View.inflate(context,R.layout.display_producto, null);
        TextView txtNombre = (TextView) convertView.findViewById(R.id.lblNombre);
        TextView txtCodigo = (TextView) convertView.findViewById(R.id.lblCodigo);
        TextView txtPrecio = (TextView) convertView.findViewById(R.id.lblPrecio);
        TextView txtExistencia = (TextView) convertView.findViewById(R.id.lblCantidad);
        TextView txtProductoIva = (TextView) convertView.findViewById(R.id.lblProductoIva);
        Producto producto = listaProducto.get(position);
        txtNombre.setText(producto.getNombre());
        txtCodigo.setText(String.valueOf(producto.getCodigo()));
        txtPrecio.setText(String.valueOf(producto.getPrecio()));
        txtExistencia.setText(String.valueOf(producto.getExistencia()));
        txtProductoIva.setText(String.valueOf(producto.getProductoIva()));
        return convertView;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public ArrayList<Producto> getListaProducto() {
        return listaProducto;
    }

    public void setListaProducto(ArrayList<Producto> listaProducto) {
        this.listaProducto = listaProducto;
    }

}
