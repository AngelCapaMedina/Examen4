package com.example.macbookpro.capamedina;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.macbookpro.capamedina.adapter.ProductoAdapter;
import com.example.macbookpro.capamedina.helper.HelperProducto;
import com.example.macbookpro.capamedina.modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    EditText cajaNombre;
    Button eliminarTodos;
    Button botonCrear;
    HelperProducto helperProductoBD;
    ListView lista;
    Producto producto;
    ArrayList<Producto> productos;
    List<Producto> listaProductos;
    ProductoAdapter productoAdapter;
    ArrayList<Producto>Item;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        helperProductoBD = new HelperProducto(this,"bdproductoex",null,1);

        lista = (ListView)findViewById(R.id.listaView);
        mostrarListView();
        lista.setOnItemClickListener(this);

        cajaNombre=(EditText)findViewById(R.id.txtNombre);
        botonCrear=(Button)findViewById(R.id.btnCrear);
        eliminarTodos = (Button) findViewById(R.id.btnElminiarTodos);
        eliminarTodos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helperProductoBD.eliminarTodos();
                mostrarListView();
            }
        });
        botonCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dlgCrearProducto = new Dialog(MainActivity.this);
                dlgCrearProducto.setContentView(R.layout.dlg_crear_producto);
                dlgCrearProducto.show();
                final EditText cajaNombre = (EditText)dlgCrearProducto.findViewById(R.id.txtNombre);
                final EditText cajaCodigo = (EditText)dlgCrearProducto.findViewById(R.id.txtCodigo);
                final EditText cajaPrecio = (EditText)dlgCrearProducto.findViewById(R.id.txtPrecio);
                Button botonGuardar = (Button)dlgCrearProducto.findViewById(R.id.btnGuardarProducto);
                botonGuardar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Producto pro = new Producto();
                        pro.setNombre(cajaNombre.getText().toString());
                        pro.setCodigo(Integer.parseInt(cajaCodigo.getText().toString()));
                        pro.setPrecio(Double.parseDouble(cajaPrecio.getText().toString()));
                        helperProductoBD.guardar(pro);
                        mostrarListView();
                        //se debe presentar el list view con el producto nuevo
                        dlgCrearProducto.hide();//Lo vamos a ocultar=hide
                    }
                });

                dlgCrearProducto.show();
            }
        });
    }
    private void mostrarListView(){
        productos = new ArrayList<Producto>();
        producto = new Producto();
        listaProductos = helperProductoBD.obtenerProductos();
        for(int i=0;i<listaProductos.size();i++){
            producto = listaProductos.get(i);
            productos.add(producto);
        }
        //le enviamos a ListView
        productoAdapter = new ProductoAdapter(MainActivity.this,productos);
        lista.setAdapter(productoAdapter);
        productoAdapter.notifyDataSetChanged();
    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        final Dialog dlgMostrarProducto = new Dialog(MainActivity.this);
        dlgMostrarProducto.setContentView(R.layout.dlg_productoonitemclicklistener);
        dlgMostrarProducto.show();

        Item = obtenerProductosItem();
        final EditText cajaNombreOnItem=(EditText)dlgMostrarProducto.findViewById(R.id.txtNombreonitem);
        cajaNombreOnItem.setText(Item.get(position).getNombre());
        final EditText cajaCodigoOnItem = (EditText)dlgMostrarProducto.findViewById(R.id.txtCodigoonitem);
        cajaCodigoOnItem.setText(String.valueOf(Item.get(position).getCodigo()));
        final EditText cajaPrecioOnItem = (EditText)dlgMostrarProducto.findViewById(R.id.txtPrecioonitem);
        cajaPrecioOnItem.setText(String.valueOf(Item.get(position).getPrecio()));
        final EditText cajaExistenciaOnItem=(EditText)dlgMostrarProducto.findViewById(R.id.txtExistenciaonitem);
        cajaExistenciaOnItem.setText(String.valueOf(Item.get(position).getExistencia()));
        final EditText cajaProductoIvaOnItem=(EditText)dlgMostrarProducto.findViewById(R.id.txtProductoIvaonitem);
        cajaProductoIvaOnItem.setText(String.valueOf(Item.get(position).getProductoIva()));
        dlgMostrarProducto.show();

        Button btnModificar = (Button)dlgMostrarProducto.findViewById(R.id.btnModificaronitem);
        Button btnEliminar = (Button)dlgMostrarProducto.findViewById(R.id.btnEliminaronitem);
        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = cajaNombreOnItem.getText().toString();
                int codigo = Integer.parseInt(cajaCodigoOnItem.getText().toString());
                Double precio = Double.parseDouble(cajaPrecioOnItem.getText().toString());
                int existencia = Integer.parseInt(cajaExistenciaOnItem.getText().toString());
                Double precioIva = Double.parseDouble(cajaProductoIvaOnItem.getText().toString());
                Toast.makeText(MainActivity.this,"Se ha modificado con exito",Toast.LENGTH_SHORT).show();
                helperProductoBD.modificar(nombre,codigo,precio,existencia,precioIva);
                mostrarListView();
                dlgMostrarProducto.hide();
            }
        });
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Producto prod = new Producto();
                prod.setNombre(cajaNombreOnItem.getText().toString());
                prod.setCodigo(Integer.parseInt(cajaCodigoOnItem.getText().toString()));
                prod.setPrecio(Double.parseDouble(cajaPrecioOnItem.getText().toString()));
                prod.setExistencia(Integer.parseInt(cajaExistenciaOnItem.getText().toString()));
                helperProductoBD.eliminar(prod);
                Toast.makeText(MainActivity.this,"Se ha eliminado con exito",Toast.LENGTH_SHORT).show();
                mostrarListView();
                dlgMostrarProducto.hide();
            }
        });
        dlgMostrarProducto.show();
    }
    private ArrayList<Producto> obtenerProductosItem(){

        productos = new ArrayList<Producto>();
        producto = new Producto();
        listaProductos = helperProductoBD.obtenerProductos();

        for(int i=0;i<listaProductos.size();i++){
            producto = listaProductos.get(i);
            productos.add(producto);
        }return productos;
    }

}
