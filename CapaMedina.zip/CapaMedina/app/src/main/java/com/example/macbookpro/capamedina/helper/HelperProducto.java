package com.example.macbookpro.capamedina.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.macbookpro.capamedina.modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class HelperProducto extends SQLiteOpenHelper {
    public HelperProducto(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE producto (id  Auto_increment Primary key , nombre VARCHAR(50),codigo INT UNIQUE  , precio DOUBLE(9,2), existencia INT, productoIva DOUBLE(9,2))");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void guardar(Producto producto){
        double mult = producto.getExistencia() * producto.getPrecio();
        double aux = mult * 0.12;
        double n = mult + aux;
        ContentValues valores = new ContentValues();
        valores.put("nombre", producto.getNombre());
        valores.put("codigo", producto.getCodigo());
        valores.put("precio", producto.getPrecio());
        valores.put("existencia", producto.getExistencia());
        valores.put("productoIva", producto.getPrecio() * 0.12);
        this.getWritableDatabase().insert("producto", null, valores);
    }

    public void modificar(String nombre, int  codigo,double precio, int existencia,double precioIva){
        ContentValues valores = new ContentValues();
        valores.put("nombre", nombre);
        valores.put("precio", precio);
        valores.put("existencia", existencia);
        valores.put("productoIva", precioIva);
        this.getWritableDatabase().update("producto", valores, "codigo ='"+codigo+"'", null);
    }

    public void eliminar(Producto prod){
        this.getWritableDatabase().delete("producto", "codigo='"+prod.getCodigo()+"'", null);
    }

    public void eliminarTodos(){
        this.getWritableDatabase().delete("producto", null, null);
    }

    public String leerTodos(){
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT *FROM PRODUCTO", null);
        String consulta = "";
        if (cursor.moveToFirst()){
            do {
                String nombre = cursor.getString(cursor.getColumnIndex("nombre"));
                Double precio = cursor.getDouble(cursor.getColumnIndex("precio"));
                String codigo = cursor.getString(cursor.getColumnIndex("codigo"));
                int existencia = cursor.getInt(cursor.getColumnIndex("existencia"));
                Double productoIv = cursor.getDouble(cursor.getColumnIndex("productoIva"));
                consulta = consulta+ "Nombre: "+ nombre+ "Precio: "+precio+ "Existencia: "+existencia+ "Codigo: "+ codigo+ "productoIva: "+ productoIv+ "\n";
            }while(cursor.moveToNext());
        }
        return consulta;
    }

    public List<Producto> obtenerProductos(){
        List<Producto> lista = new ArrayList<Producto>();
        String resultado=null;
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT *FROM PRODUCTO ", null);
        String consulta = "";
        if (cursor.moveToFirst()){
            do {
                String nombre = cursor.getString(cursor.getColumnIndex("nombre"));
                Double precio = cursor.getDouble(cursor.getColumnIndex("precio"));
                int codigo = cursor.getInt(cursor.getColumnIndex("codigo"));
                int existencia = cursor.getInt(cursor.getColumnIndex("existencia"));
                Double precioiv = cursor.getDouble(cursor.getColumnIndex("productoIva"));
                Producto producto = new Producto();
                producto.setNombre(nombre);
                producto.setCodigo(codigo);
                producto.setPrecio(precio);
                producto.setExistencia(existencia);
                producto.setProductoIva(precioiv);
                lista.add(producto);
            }while(cursor.moveToNext());
        }
        return lista;
    }

}
