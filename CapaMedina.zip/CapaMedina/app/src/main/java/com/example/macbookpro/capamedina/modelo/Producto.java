package com.example.macbookpro.capamedina.modelo;

public class Producto {
    private String nombre;
    private int codigo;
    private double precio;
    private int existencia;
    private double productoIva;

    public double getProductoIva() {
        return productoIva;
    }

    public void setProductoIva(double productoIva) {
        this.productoIva = productoIva;
    }

    public Producto() {

    }


    public Producto(String nombre, int codigo, double precio, int existencia, double productoIva) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;
        this.existencia = existencia;
        this.productoIva = productoIva;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getExistencia() {
        return existencia;
    }

    public void setExistencia(int existencia) {
        this.existencia = existencia;
    }
}
